1. Upload everything in this folder to a GitHub repo (keep .github/workflows).
2. Actions > build > Run workflow. Download the "myclient-jar" artifact when done.
3. Unzip it, put myclient-1.0.0.jar in mods (needs Fabric Loader + Fabric API for 1.21.11).
In game: Right Shift or type /gui in chat. Pick a category tab, tap a module to toggle,
use - / + to change its value (range, speed, etc).
Modules: KillAura, Reach | Sprint, Speed, Fly, Step | ESP, Fullbright, Zoom | HUD
If the build fails, paste the error log.
