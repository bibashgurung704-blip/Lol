package me.myclient.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public enum Category {
        COMBAT("Combat"), MOVEMENT("Movement"), RENDER("Render"), MISC("Misc");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public final String name;
    public final Category category;
    private boolean enabled;

    // optional numeric setting (range, speed, etc.)
    public boolean hasValue;
    public double value, min, max, step;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public Module value(double def, double min, double max, double step) {
        this.hasValue = true;
        this.value = def; this.min = min; this.max = max; this.step = step;
        return this;
    }

    public void adjust(int dir) {
        value = Math.round((value + dir * step) * 1000.0) / 1000.0;
        value = Math.max(min, Math.min(max, value));
    }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}
}
