package me.myclient.module;

import me.myclient.module.Module.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private static boolean moving(MinecraftClient mc) {
        return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
            || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
    }

    // ---------------- COMBAT ----------------
    public static final Module KILLAURA = new Module("KillAura", Category.COMBAT) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
            if (mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
            LivingEntity best = null;
            double bestDist = value * value;
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof PlayerEntity) || e == mc.player) continue;
                LivingEntity le = (LivingEntity) e;
                if (!le.isAlive()) continue;
                double d = mc.player.squaredDistanceTo(e);
                if (d < bestDist) { bestDist = d; best = le; }
            }
            if (best != null) {
                mc.interactionManager.attackEntity(mc.player, best);
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }.value(3.5, 2.0, 6.0, 0.5);

    public static final Module REACH = new Module("Reach", Category.COMBAT) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null) return;
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a != null) a.setBaseValue(value);
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a != null) a.setBaseValue(3.0);
        }
    }.value(4.5, 3.0, 6.0, 0.5);

    // ---------------- MOVEMENT ----------------
    public static final Module SPRINT = new Module("Sprint", Category.MOVEMENT) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player != null && mc.options.forwardKey.isPressed() && !mc.player.isSneaking()) {
                mc.player.setSprinting(true);
            }
        }
    };

    public static final Module SPEED = new Module("Speed", Category.MOVEMENT) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null || !mc.player.isOnGround() || !moving(mc)) return;
            Vec3d v = mc.player.getVelocity();
            mc.player.setVelocity(v.x * value, v.y, v.z * value);
        }
    }.value(1.15, 1.0, 2.0, 0.05);

    public static final Module FLY = new Module("Fly", Category.MOVEMENT) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null) return;
            mc.player.getAbilities().allowFlying = true;
            mc.player.getAbilities().setFlySpeed((float) (value * 0.05));
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.player.isCreative() || mc.player.isSpectator()) return;
            mc.player.getAbilities().allowFlying = false;
            mc.player.getAbilities().flying = false;
            mc.player.getAbilities().setFlySpeed(0.05f);
        }
    }.value(1.0, 0.5, 5.0, 0.5);

    public static final Module STEP = new Module("Step", Category.MOVEMENT) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player == null) return;
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(value);
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null) return;
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(0.6);
        }
    }.value(1.0, 0.6, 2.5, 0.5);

    // ---------------- RENDER ----------------
    public static final Module ESP = new Module("ESP", Category.RENDER) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.world == null) return;
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof PlayerEntity && e != mc.player) e.setGlowing(true);
            }
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null) return;
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof PlayerEntity) e.setGlowing(false);
            }
        }
    };

    public static final Module FULLBRIGHT = new Module("Fullbright", Category.RENDER) {
        @Override public void onTick(MinecraftClient mc) {
            if (mc.player != null) {
                mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false));
            }
        }
        @Override public void onDisable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    };

    public static final Module ZOOM = new Module("Zoom", Category.RENDER) {
        private int oldFov = 70;
        @Override public void onEnable() {
            MinecraftClient mc = MinecraftClient.getInstance();
            oldFov = mc.options.getFov().getValue();
            mc.options.getFov().setValue(30);
        }
        @Override public void onDisable() {
            MinecraftClient.getInstance().options.getFov().setValue(oldFov);
        }
    };

    // ---------------- MISC ----------------
    public static final Module HUD = new Module("HUD", Category.MISC) {};

    public static void init() {
        MODULES.add(KILLAURA); MODULES.add(REACH);
        MODULES.add(SPRINT); MODULES.add(SPEED); MODULES.add(FLY); MODULES.add(STEP);
        MODULES.add(ESP); MODULES.add(FULLBRIGHT); MODULES.add(ZOOM);
        MODULES.add(HUD);
        HUD.setEnabled(true);
    }

    public static List<Module> all() { return MODULES; }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
    }
}
