package me.myclient.gui;

import me.myclient.module.Module;
import me.myclient.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    private static Module.Category selected = Module.Category.COMBAT;

    public ClickGuiScreen() { super(Text.literal("ClickGUI")); }

    private static Text label(Module m) {
        String s = m.name + ": " + (m.isEnabled() ? "ON" : "OFF");
        if (m.hasValue) s += " (" + m.value + ")";
        return Text.literal(s);
    }

    @Override
    protected void init() {
        int x = 10;
        for (Module.Category c : Module.Category.values()) {
            String t = (c == selected ? "> " : "") + c.label;
            addDrawableChild(ButtonWidget.builder(Text.literal(t), b -> {
                selected = c;
                clearAndInit();
            }).dimensions(x, 10, 72, 20).build());
            x += 76;
        }

        int y = 45;
        for (Module m : ModuleManager.all()) {
            if (m.category != selected) continue;
            ButtonWidget toggle = ButtonWidget.builder(label(m), b -> {
                m.toggle();
                b.setMessage(label(m));
            }).dimensions(10, y, 150, 20).build();
            addDrawableChild(toggle);
            if (m.hasValue) {
                addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> {
                    m.adjust(-1);
                    toggle.setMessage(label(m));
                }).dimensions(164, y, 20, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> {
                    m.adjust(1);
                    toggle.setMessage(label(m));
                }).dimensions(188, y, 20, 20).build());
            }
            y += 24;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
