package me.myclient;

import me.myclient.gui.ClickGuiScreen;
import me.myclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MyClient implements ClientModInitializer {
    private static KeyBinding guiKey;
    private static boolean openNext = false;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();

        guiKey = KeyBindingHelper.registerKeyBinding(
            new KeyBinding("key.myclient.gui", GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null) return;
            while (guiKey.wasPressed()) openNext = true;
            if (openNext) { openNext = false; mc.setScreen(new ClickGuiScreen()); }
            ModuleManager.tick(mc);
        });

        // Touch-friendly: type /gui in chat to open the ClickGUI
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("gui").executes(ctx -> {
                openNext = true;
                return 1;
            })));

        HudElementRegistry.attachElementAfter(
            VanillaHudElements.MISC_OVERLAYS,
            Identifier.of("myclient", "hud"),
            (ctx, tick) -> {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player == null || !ModuleManager.HUD.isEnabled()) return;
                ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 4, 4, 0xFFFFFFFF);
                String xyz = String.format("XYZ: %.1f %.1f %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
                ctx.drawTextWithShadow(mc.textRenderer, xyz, 4, 16, 0xFFFFFFFF);
            });
    }
}
